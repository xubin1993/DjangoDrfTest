# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：    urls
   Description :
   Author :       xubin
   date：         2018/11/20 17:15
-------------------------------------------------
   Change Activity:
                  2018/11/20 17:15:
-------------------------------------------------
"""
__author__ = 'xubin'
import sys

reload(sys)
sys.setdefaultencoding('utf-8')
sys.path.append('../')
from django.conf.urls import url
from views import *

urlpatterns = [
    url(r'^getOneNews/?$', GetOneNews.as_view(), name='cc_delete_crawl'),  # 爬虫管理

]


